class Student{
  constructor(name, lastName, indexNr, grades){
    this.name = name;
    this.lastName = lastName;
    this.inexNr = idenxNr;
    this.grades = grades;
  }
  getAvg(){
    var sum = 0;
    for(var i = 0; i<this.grades.length; i++){
        sum += parseInt(this.grades[i], radix:10)
  }
    return sum / this.grades.length;

  }
  get info(){
    return "Name: "+this.name + "\n" + "Last Name: "+this.lastName + "\n" +
        "Average grade: "+ this.getAvg();

  }

}
var michal = new Student(name: "Michał", lastName: "Szewczyk", indexNr:"s18772", grades:[5,3,4,4])
console.log(michal.info)
