
var student = {
  imie: "Michał",
  nazwisko: "Szewczyk",
  nr_indeksu: "s18772"
};

console.log("Dane nowego studenta: ");
console.log(JSON.stringify(student));
