var student_s18772 = {imie:"Michał", nazwisko: "Szewczyk", index:"s18772", oceny:[5, 3, 4, 4]};

var total = 0;
for(var i = 0; i < student_s18772.oceny.length; i++){
  total += student_s18772.oceny.length;
}
var avg = total / student_s18772.oceny.length;

console.log(student_s18772);
console.log("srednia ocen:", avg);
