
var student1 = {
  imie: "Michał",
  nazwisko: "Szewczyk",
  nr_indeksu: "s18772"
};

console.log(student1.imie + " " + student1.nazwisko + " " + student1.nr_indeksu);
