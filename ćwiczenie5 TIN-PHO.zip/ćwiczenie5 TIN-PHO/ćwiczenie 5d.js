var liczba1 = 1;
var liczba2 = 2;
var liczba3 = 5;
function czywieksza(x){
  if (x < Math.max(liczba2,liczba3) && x > Math.min(liczba2,liczba3))
    return ("Liczba " + liczba1 + " znajduje się w zakresie między " + liczba2 + " a " + liczba3);
  else
    return ("Liczba " + liczba1 + " NIE znajduje się w zakresie między " + liczba2 + " a " + liczba3);
}
document.write(czywieksza(liczba1));
