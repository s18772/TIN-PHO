var liczba = 32;
function czyparzy(x){
  if (x%2 == 0)
    return ("Jest parzysta");
  else
    return ("Nie jest parzysta");
}
document.write(czyparzy(liczba));
